#include "servoclass.h"

// Constructor
servoclass::servoclass(int pinR, int pinL) {
    sr.attach(pinR);
    sl.attach(pinL); // Attach the servo to the specified pin
}
void servoclass::setPosition(int posR, int posL) {
    sr.write(posR);  // Move right servo
    sl.write(posL);  // Move left servo
}

// Easing function (circular)
float servoclass::easeInOutCirc(float x) {
    return x < 0.5 ? (1 - sqrt(1 - pow(2 * x, 2))) / 2 : (sqrt(1 - pow(-2 * x + 2, 2)) + 1) / 2;
}

// Servo motion with easing
void servoclass::servomotion_ease(int Spos, int Epos, int time) {
    unsigned long stepDuration = (time * 1000) / steps; // Convert to microseconds
    
    for (int currentStep = 0; currentStep <= steps; currentStep++) {
        unsigned long currentMicros = micros();
        
        while (micros() - currentMicros < stepDuration) {
            // Non-blocking delay
        }
        
        float progress = (float)currentStep / steps;
        float easedProgress = easeInOutCirc(progress);
        
        int servoPos = Spos + round((Epos - Spos) * easedProgress);
        sr.write(servoPos);
        sl.write(180 - servoPos);
    }
}

void servoclass::servomotion(int startangle, int endangle){
  if (startangle < endangle) {
      for (int angle = startangle; angle <= endangle + 4; angle++) {
        sr.write(angle);
        if (angle < endangle) {
          sl.write(180 - angle);
        }
        delay(15);
      }
    }

    if (startangle > endangle) {
      for (int angle = startangle; angle >= endangle; angle--) {
        // if(angle<125)
        sr.write(angle);
        //Serial.println(180-angle);
        sl.write(180 - angle);
        //Serial.println(angle);
        delay(15);
      }
    }
}

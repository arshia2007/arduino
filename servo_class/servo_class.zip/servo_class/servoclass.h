#ifndef SERVOCLASS_H
#define SERVOCLASS_H

#include <Arduino.h>
#include <Servo.h>  // Use Teensy-compatible Servo library
#include <cmath>

class servoclass {
public:
    servoclass(int pinR, int pinL);  // Constructor
    void setPosition(int posR, int posL);
    void servomotion_ease(int Spos, int Epos, int time);
    void servomotion(int startangle, int endangle);

private:
    Servo sr, sl;  // Use PWMServo instead of Servo
    static constexpr int steps = 100;
    float easeInOutCirc(float x);
};

#endif
